# Hero Image CTA

A full width image with centered formatted text. Image gets cropped when resized. Optional mobile image, full width option and image alignment settings. Linebreaks (br-tags) convert to spaces on mobile for individual text flow control on desktop.

