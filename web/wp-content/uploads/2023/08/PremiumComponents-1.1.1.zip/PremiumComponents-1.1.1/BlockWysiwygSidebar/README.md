# Block WYSIWYG Sidebar

Simple formatted text from a „What You See Is What You Get“ editor, with a WYSIWYG sidebar.
