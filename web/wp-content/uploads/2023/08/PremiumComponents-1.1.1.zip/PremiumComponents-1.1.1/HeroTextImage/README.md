# Hero Text Image

Focuses on content and cuts the fixed height image off starting from the outer side. Text can be positioned on the left or right side. Any image aspect ratio can be used and will extend outside the container if too wide.
