# Block Image Text Parallax

Image and text have almost equal weight, but focus is on the image, as it’s having a parallax movement while scrolling past the component.
