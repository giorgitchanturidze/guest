# Accordion Default

A simple accordion built with accessibility in mind. Each accordion panel provides a title and formatted text content, which is toggled with a jQuery slide animation.
