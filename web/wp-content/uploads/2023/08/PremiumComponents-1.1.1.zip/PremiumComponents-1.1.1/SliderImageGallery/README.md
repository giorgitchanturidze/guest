# Slider Image Gallery

Drop any images on the gallery field, order them by drag & drop and optionally add a caption per image. Any image ratio will fit into the slider. It always covers the full width of the website container and comes with a thumbnail preview navigation.
