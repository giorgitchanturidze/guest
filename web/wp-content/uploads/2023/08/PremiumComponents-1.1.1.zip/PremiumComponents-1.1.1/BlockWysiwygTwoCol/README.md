# Block WYSIWYG Two Col

Simple 2 column formatted text from a „What You See Is What You Get“ editor, wrapped in a max width container for a convenient reading experience.
